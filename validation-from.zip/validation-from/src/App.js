import React, { useState } from "react";
import Form1 from "./components/Form1";
import DisplayCard from "./components/DisplayCard";
import { useForm, FormProvider } from "react-hook-form";
import "./components/Form1.css";
import { Grid } from "@mui/material";
// import { useState } from "react";

function App() {
  const form = useForm();
  const [card, setCard] = useState([]);
  const onSubmit = (data) => {
    setCard((prevData) => [...prevData, data]);
    form.reset('');
  };

  const onError = (error) => {
    console.log(error);
  };

  const displayCard = card.map((etem, index) => {
    return (
      <DisplayCard
      key={etem.associateID}
        associateID={etem.associateID}
        d_name={etem.associateName}
        phone={etem.associatePhone}
        address={etem.associateAddress}
        specialization={etem.associateSpecialization}
      />
    );
  });
  console.log(card);
  return (
    <>
      <FormProvider {...form}>
        <form
          className="contain"
          onSubmit={form.handleSubmit(onSubmit, onError)}
        >
          <Form1 />
        </form>
      </FormProvider>
      <Grid container spacing={2} md={10} style={{margin:'0 auto'}}>
      {displayCard}
      </Grid>
    </>
  );
}

export default App;
