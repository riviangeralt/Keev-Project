import React from "react";
import { TextField, Button } from "@mui/material";
import { useFormContext, Controller, useFormState } from "react-hook-form";

export default function ControllerComp(props) {
  const formState = useFormState();
  const formContext = useFormContext();
  // const rules = "This field is required";
  return (
    <Controller
      name={props.name}
      render={({
        field: { onChange, onBlur, value, name, ref },
        //   fieldState: { invalid, isTouched, isDirty, error },
        //   formState,
      }) => (
        <TextField
          name={props.name}
          id={props.id}
          label={props.label}
          defaultValue=""
          onChange={onChange}
          onBlur={onBlur}
          value={value}
          ref={ref}
          error={Boolean(formState.errors && formState.errors[name])}
          helperText={formState.errors && formState.errors[name]?.message}
        />
      )}
      rules={props.rules}
    />
  );
}
