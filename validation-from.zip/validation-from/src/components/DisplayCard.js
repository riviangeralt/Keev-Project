import React from "react";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { Grid, Paper } from "@mui/material";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";

export default function DisplayCard(props) {
  return (
    <>
      <Grid item md={3} style={{ margin: "1rem 0" }}>
        <Paper style={{ backgroundColor: "#c0c0c0" }}>
          <CardContent>
            <Typography
              sx={{ fontSize: 14 }}
              color="text.secondary"
              gutterBottom
            >
              {props.associateID}
            </Typography>
            <Typography variant="h5" component="div">
              {props.d_name}
            </Typography>
            <Typography sx={{ mb: 1.5 }} color="text.secondary">
              {props.phone}
            </Typography>
            <Typography variant="body2">{props.address}</Typography>
            <Typography variant="body2">{props.specialization}</Typography>
          </CardContent>
          <CardActions>
            <Button size="small" style={{width:'100%'}}>
              <Router>
                <Link to="/update">Update Info</Link>
              </Router>
            </Button>
          </CardActions>
        </Paper>
      </Grid>
    </>
  );
}
