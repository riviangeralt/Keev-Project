import React from "react";
import { TextField, Button } from "@mui/material";
// import { Controller, useFormState } from "react-hook-form";
import ControllerComp from "./ControllerComp";

export default function Form1() {
  //   const formContext = useFormContext();
//   const rules = "This field is required";

  return (
    <>
      <ControllerComp
        name="associateID"
        id="outlined-required"
        label="Associate ID"
        rules={{ required: 'ID Is required' }}
      />
      <br />
      <ControllerComp
        name="associateName"
        id="outlined-required"
        label="Associate Name"
        rules={{ required: 'Name is Required' }}
      />{" "}
      <br />
      <ControllerComp
        name="associatePhone"
        id="outlined-required"
        label="Phone"
        rules={{ required: 'Phone No is Required' }}
      />{" "}
      <br />
      <ControllerComp
        name="associateAddress"
        id="outlined-required"
        label="Address"
        rules={{ required: "Address is Required" }}
      />{" "}
      <br />
      <ControllerComp
        name="associateSpecialization"
        id="outlined-required"
        label="Specialization"
        rules={{ required: 'Specialization is required' }}
      />
      <br />
      <Button variant="contained" type="Submit">
        Submit
      </Button>
    </>
  );
}
